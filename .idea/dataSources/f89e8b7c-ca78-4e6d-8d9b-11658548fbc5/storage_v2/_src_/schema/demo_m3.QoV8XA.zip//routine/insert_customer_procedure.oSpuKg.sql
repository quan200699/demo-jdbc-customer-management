create
    definer = root@localhost procedure insert_customer_procedure(IN inputName varchar(50), IN inputAddress varchar(50))
Begin
    insert into customers (name, address)
    Values (inputName, inputAddress);
end;

